package com.eif.data;

public class Cars {

	public void add(Cars cs) {
		// TODO Auto-generated method stub
		
	}

}
