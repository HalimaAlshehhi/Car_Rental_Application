package com.eif.data;

public class Orders {

	public void add(Orders os) {
		// TODO Auto-generated method stub
		
	}

}
