package com.eif.service;

public class Autowired {

}
