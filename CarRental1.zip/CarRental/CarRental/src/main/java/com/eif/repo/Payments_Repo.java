package com.eif.repo;

public interface Payments_Repo {

}
