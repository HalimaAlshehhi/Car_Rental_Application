import Navbar from './Components/Navbar';
import './App.css';
import { BrowserRouter as Router, Route, Routes as Switch } from "react-router-dom";
import Home from './Components/Home';
import Cars from './Components/Cars';
import AboutUs from './Components/AboutUs';
import Signup from './Components/Signup';
import Login from './Components/Login';
import Transportation from './Components/Transportation';
import Payment from './Components/Payments';
import CashOnDelivery from './DBuse/CashOnDelivery'
import CreditCard from './DBuse/CreditCard'
function App() {
  return (<Router>    <div className="App">
    <Navbar></Navbar>
  </div>      <Switch>
      <Route exact path='/' element={<Home />} />
      <Route exact path='/Cars' element={<Cars />} />
      <Route exact path='/aboutus' element={<AboutUs />} />
      <Route path='/Signup' element={<Signup />} />
      <Route path='/Login' element={<Login />} />
      <Route path='/Transportation' element={<Transportation />} />
      <Route path='/Cars' element={<Cars />} />
      <Route path='/payment' element={<Payment />} />
      <Route path="/cash-on-delivery" element={<CashOnDelivery />} />
      <Route path="/credit-card" element={<CreditCard />} />

    </Switch>
  </Router>

  );
}


export default App;
