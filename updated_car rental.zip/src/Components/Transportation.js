import React from "react";
import { Link } from "react-router-dom";
import Dropdown from "./Dropdown";
import img from '../Assets/Images/car 3.jpeg'
function Transportation() {
    return (
        <div>
            <div className="container-fluid">
                <div className="row d-flex justify-content-center align-items-center vh-100">
                    <div className="col-md-2 col-lg-2"></div>
                    {/* Form Section */}
                    <div className="bg-white p-3 rounded col-md-6 col-lg-6">
                        <h2 className="mb-4">Please fill in your address for Delivery</h2>
                        <Dropdown />
                        <form action="">
                            <div className="mb-3">
                                <label htmlFor="streetName">Street Name </label>
                                <br />
                                <input
                                    type="text"
                                    placeholder="Enter Street Name"
                                    className="form-control rounded-0"
                                />
                            </div>

                            <div className="mb-3">
                                <label htmlFor="houseNumber">House Number</label>
                                <br />
                                <input
                                    type="text"
                                    placeholder="Enter House Number"
                                    className="form-control rounded-0"
                                />
                            </div>

                            <br />
                            <Link
                                to="/payment"
                                className="btn btn-default btn-success border w-100 text-decoration-none mb-2"
                            >
                                Submit
                            </Link>
                            <br />
                        </form>
                    </div>

                    {/* Image Section */}
                    <div className="col-md-4 col-lg-4 d-none d-lg-block">
                        <img
                            src={img} // Update with the correct path to your image
                            alt="Car Image"
                            className="img-fluid rounded"
                        />
                    </div>
                </div>
            </div>

        </div>
    );
}

export default Transportation;
