import React, { useState } from 'react';

const Dropdown = () => {
  const [selectedOption, setSelectedOption] = useState('');

  const handleDropdownChange = (event) => {
    setSelectedOption(event.target.value);
  };

  return (
    <div className="mb-3">
      <label htmlFor="dropdown" className="form-label">
        Select City:
      </label>
      <select
        id="dropdown"
        value={selectedOption}
        onChange={handleDropdownChange}
        className="form-select w-100"
      >
        <option value="">Select...</option>
        <option value="Abu Dhabi">Abu Dhabi</option>
        <option value="Al Ain">Al Ain</option>
        <option value="Dubai">Dubai</option>
        <option value="Sharjah">Sharjah</option>
        <option value="Ajman">Ajman</option>
        <option value="Ras Al Khaimah">Ras Al Khaimah</option>
        <option value="Umm Al Quwain">Umm Al Quwain</option>
        <option value="Fujairah">Fujairah</option>
      </select>
      {selectedOption && <p>You selected: {selectedOption}</p>}
    </div>
  );
};

export default Dropdown;
