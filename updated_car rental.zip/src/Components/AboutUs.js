import React from 'react';
import { useState } from 'react';
import pic from './logo.jpg';
import './styles.css';

const AboutUs = () => {
    return (
        <div className="AboutUsContainer">
            

            <div className="TextContainer">
                <h1>Welcome to Car Rental</h1>

                <p>
                    Where we redefine your journey with seamless and reliable car rental solutions.
                    With a commitment to providing exceptional service, we pride ourselves on offering a fleet of
                    vehicles that caters to every need and occasion.
                </p>

                {/* Repeat the pattern for other text sections */}

                <h2>Thank you for choosing Car Rental, where every mile is a memory waiting to be made!</h2>
            </div>
        </div>
    );
};

export default AboutUs;

