// Cars.js

import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './Cars.css'; // Import the CSS file

// Import car images
import Kia from './images/White-Kia.jpeg';
import Toyota from './images/toyota.jpeg';
import Honda from './images/Honda.jpeg';
import Lexus from './images/lexus GX.jpeg';
import Mercedes from './images/mercedes.jpeg';
import Ford from './images/Ford.jpeg';
import Nissan from './images/Nissan.jpeg';
import LandRover from './images/land rover.jpeg';
import Chevrolet from './images/cheverlote.jpeg';

const Cars = () => {
  const navigate = useNavigate();

  const [cars, setCars] = useState([
    { image: Kia, brandname: 'Kia', carsize: 'small', carmodel: 'Picanto', carseats: '5', extras: '122', year: '2019', color: 'White', priceperday: '250' },
    { image: Toyota, brandname: 'Toyota', carsize: 'small', carmodel: 'Yaris', carseats: '5', extras: '117', year: '2020', color: 'Red', priceperday: '150' },
    { image: Honda, brandname: 'Honda', carsize: 'SUV', carmodel: 'CRV', carseats: '5', extras: '135', year: '2017', color: 'Silver', priceperday: '200' },
    { image: Ford, brandname: 'Ford', carsize: 'SUV', carmodel: 'EcoSport', carseats: '5', extras: '167', year: '2021', color: 'White', priceperday: '300' },
    { image: Nissan, brandname: 'Nissan', carsize: 'Large', carmodel: 'Patrol', carseats: '7', extras: '750', year: '2022', color: 'White', priceperday: '400' },
    { image: LandRover, brandname: 'Land Rover', carsize: 'Premium', carmodel: 'Range Rover', carseats: '7', extras: '1800', year: '2022', color: 'Black', priceperday: '700' },
    { image: Chevrolet, brandname: 'Chevrolet', carsize: 'Small', carmodel: 'Malibu', carseats: '5', extras: '205', year: '2016', color: 'Gold', priceperday: '100' },
    { image: Lexus, brandname: 'Lexus', carsize: 'Large', carmodel: 'GX', carseats: '7', extras: '780', year: '2021', color: 'Silver', priceperday: '700' },
    { image: Mercedes, brandname: 'Mercedes', carsize: 'Premium', carmodel: 'Maybach', carseats: '4', extras: '4000', year: '2023', color: 'White', priceperday: '3500' },
  ]);

  const handleSubmit = (selectedCar) => {
    console.log('Submit button clicked for:', selectedCar);
    navigate('/Transportation');
  };

  return (
    <div>
      <h3>Choose Your Cars</h3>
      <table>
        <thead>
          <tr>
            
            <th>Choose</th>
            <th>Images</th>
            <th>Brand</th>
            <th>Size</th>
            <th>Model</th>
            <th>Seats</th>
            <th>Extras</th>
            <th>Year</th>
            <th>Color</th>
            <th>Price</th>
          </tr>
        </thead>

        <tbody>
          {cars.map((car) => (
            <tr key={car.brandname}>
              <td>
                <button onClick={() => handleSubmit(car)}>Add Car</button>
              </td>
              <td>
                <img className='car-img' src={car.image} alt={`${car.brandname} car`} />
              </td>
              <td>{car.brandname}</td>
              <td>{car.carsize}</td>
              <td>{car.carmodel}</td>
              <td>{car.carseats}</td>
              <td>{car.extras}</td>
              <td>{car.year}</td>
              <td>{car.color}</td>
              <td>{car.priceperday}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default Cars;