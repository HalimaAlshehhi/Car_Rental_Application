import React from "react";
import './home.css'; 

const Home = () => {
  return (
    <div class="home-container">
  <div class="text-container">
    
    <div class="content">
      <h2>Book a car near you and<br />drive in minutes!</h2>
    </div>
  </div>
</div>
  );
};

export default Home;
