import useFetch from "./UseFetch";
import Cars from "./Cars";
const PrintCars = () => {
  const { error, isPending, data: products } = useFetch('http://localhost:9090/products')

  return (
    <div className="Cars">
      { error && <div>{ error }</div> }
      { isPending && <div>Loading...</div> }
      { Cars && <cars cars={Cars} /> }
    </div>
  );
}

export default PrintCars;