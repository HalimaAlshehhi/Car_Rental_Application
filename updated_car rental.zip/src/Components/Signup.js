import React from "react";
import { Link } from "react-router-dom";

function Signup() {
    return (
        <div className="d-flex justify-content-center align-items-center bg-primary vh-100">
            <div className="bg-white p-3 rounded col-md-4">
                <h2>Sign Up</h2>
                <form action="">
                    <div className="mb-3">
                        <label htmlFor="fullName">Full name</label>
                        <br />
                        <input
                            type="text"
                            placeholder="Enter name"
                            className="form-control rounded-0"
                        />
                    </div>

                    <div className="mb-3">
                        <label htmlFor="phoneNumber">Phone Number</label>
                        <br />
                        <input
                            type="tel"
                            placeholder="+971 ** *** ****"
                            className="form-control rounded-0"
                        />
                    </div>

                    <div className="mb-3">
                        <label htmlFor="dob">Date of birth</label>
                        <br />
                        <input
                            type="text"
                            placeholder="dd/mm/yyyy"
                            className="form-control rounded-0"
                        />
                    </div>

                    <div className="mb-3">
                        <label htmlFor="email">Email</label>
                        <br />
                        <input
                            type="email"
                            placeholder="Enter email"
                            className="form-control rounded-0"
                        />
                    </div>

                    <div className="mb-3">
                        <label htmlFor="password">Password</label>
                        <br />
                        <input
                            type="password"
                            placeholder="Enter password"
                            className="form-control rounded-0"
                        />
                    </div>
                    <br />
                    <Link
                        to="/Cars"
                        className="btn btn-primary w-100 text-decoration-none mb-2"
                    >
                        Create account
                    </Link>
                    <br />
                    <Link to="/Login" className="btn btn-link w-100">
                        Log in
                    </Link>
                </form>
            </div>
        </div>
    );
}

export default Signup;
