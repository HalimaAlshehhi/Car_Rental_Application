import { useState } from "react"
  const Home = ()=>{
    const [name,setName] = useState('/');
    const [age,setAge] = useState('/');
    const [dob,setDob] = useState('/');

    const handleClick = (e)=>{
        console.log(" Submit ")
        console.log(e)
    }}